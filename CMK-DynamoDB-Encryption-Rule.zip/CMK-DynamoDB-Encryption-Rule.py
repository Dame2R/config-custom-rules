import boto3
import json
from rdklib import Evaluator, Evaluation, ConfigRule, ComplianceType

APPLICABLE_RESOURCES = ['AWS::DynamoDB::Table', 'AWS::DAX::Cluster']

class CMKDynamoDBEncryptionRule(ConfigRule):

    def evaluate_change(self, event, client_factory, configuration_item, valid_rule_parameters):
        dynamodb_client = client_factory.build_client('dynamodb')
        dax_client = client_factory.build_client('dax')
        compliance_results = []

        # Überprüfen der DynamoDB-Tabelle
        if configuration_item['resourceType'] == 'AWS::DynamoDB::Table':
            dynamodb_response = dynamodb_client.describe_table(TableName=configuration_item['resourceName'])
            if 'SSEDescription' in dynamodb_response['Table'] and dynamodb_response['Table']['SSEDescription']['Status'] == 'ENABLED':
                compliance_results.append(ComplianceType.COMPLIANT)
            else:
                compliance_results.append(ComplianceType.NON_COMPLIANT)

        # Überprüfen des DAX-Clusters
        elif configuration_item['resourceType'] == 'AWS::DAX::Cluster':
            dax_response = dax_client.describe_clusters(ClusterNames=[configuration_item['resourceName']])
            if dax_response['Clusters'][0]['SSEDescription']['Status'] == 'ENABLED':
                compliance_results.append(ComplianceType.COMPLIANT)
            else:
                compliance_results.append(ComplianceType.NON_COMPLIANT)

        # Kombinierte Compliance-Bewertung
        if all(result == ComplianceType.COMPLIANT for result in compliance_results):
            return [Evaluation(ComplianceType.COMPLIANT)]
        else:
            return [Evaluation(ComplianceType.NON_COMPLIANT)]
    #def evaluate_periodic(self, event, client_factory, valid_rule_parameters):
    #    pass

    def evaluate_parameters(self, rule_parameters):
        valid_rule_parameters = rule_parameters
        return valid_rule_parameters


################################
# DO NOT MODIFY ANYTHING BELOW #
################################
def lambda_handler(event, context):
    my_rule = CMKDynamoDBEncryptionRule()
    evaluator = Evaluator(my_rule, APPLICABLE_RESOURCES)
    return evaluator.handle(event, context)
