import boto3
import json
from botocore.exceptions import ClientError
from rdklib import Evaluator, Evaluation, ConfigRule, ComplianceType

APPLICABLE_RESOURCES = ["AWS::S3::Bucket"]

class S3BucketAccessControlRule(ConfigRule):

    def evaluate_change(self, event, client_factory, configuration_item, valid_rule_parameters):
        s3_client = client_factory.build_client("s3")
        bucket_name = configuration_item["resourceName"]

        try:
            acl = s3_client.get_bucket_acl(Bucket=bucket_name)
            for grant in acl['Grants']:
                if 'URI' in grant['Grantee']:
                    if grant['Grantee']['URI'] in ["http://acs.amazonaws.com/groups/global/AllUsers", 
                                                   "http://acs.amazonaws.com/groups/global/AuthenticatedUsers"]:
                        return [Evaluation(ComplianceType.NON_COMPLIANT)]
            return [Evaluation(ComplianceType.COMPLIANT)]

        except ClientError as e:
            print(f"Error getting ACL for bucket {bucket_name}: {e}")
            return [Evaluation(ComplianceType.NOT_APPLICABLE)]

    def evaluate_parameters(self, rule_parameters):
        return rule_parameters

################################
# DO NOT MODIFY ANYTHING BELOW #
################################
def lambda_handler(event, context):
    my_rule = S3BucketAccessControlRule()
    evaluator = Evaluator(my_rule, APPLICABLE_RESOURCES)
    return evaluator.handle(event, context)
